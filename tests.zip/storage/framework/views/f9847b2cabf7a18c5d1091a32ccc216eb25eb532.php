
	<script>
		function GoogleLanguageTranslatorInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages:'zh-CN,en,fr,de,it,pt,es,tr', autoDisplay: false}, 'google_language_translator');}
	</script>                
	<style type="text/css" media="all"
		id="siteorigin-panels-layouts-footer">/* Layout w5da4be2c1213f */ #pgc-w5da4be2c1213f-0-0 { width:100%;width:calc(100% - ( 0 * 30px ) ) } #pl-w5da4be2c1213f .so-panel , #pl-w5da4be2c1213f .so-panel:last-child { margin-bottom:0px } #pg-w5da4be2c1213f-0> .panel-row-style { padding:0px } #pg-w5da4be2c1213f-0.panel-no-style, #pg-w5da4be2c1213f-0.panel-has-style > .panel-row-style { -webkit-align-items:center;align-items:center } @media (max-width:780px){ #pg-w5da4be2c1213f-0.panel-no-style, #pg-w5da4be2c1213f-0.panel-has-style > .panel-row-style { -webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column } #pg-w5da4be2c1213f-0 > .panel-grid-cell , #pg-w5da4be2c1213f-0 > .panel-row-style > .panel-grid-cell { width:100%;margin-right:0 } #pg-w5da4be2c1213f-0 { margin-bottom:px } #pl-w5da4be2c1213f .panel-grid-cell { padding:0 } #pl-w5da4be2c1213f .panel-grid .panel-grid-cell-empty { display:none } #pl-w5da4be2c1213f .panel-grid .panel-grid-cell-mobile-last { margin-bottom:0px }  } 
	</style>	
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})()
	</script>
	<link rel='stylesheet' id='mediaelement-css'  href='<?php echo e(asset('frontend/wp-includes/js/mediaelement/mediaelementplayer-legacy.minc270.css?ver=4.2.13-9993131')); ?>' type='text/css' media='all' />
	<link rel='stylesheet' id='wp-mediaelement-css'  href='<?php echo e(asset('frontend/wp-includes/js/mediaelement/wp-mediaelement.mind03b.css?ver=5.5.1')); ?>' type='text/css' media='all' />
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/contact-form-7-style/js/frontend-min20f0.html?ver=3.1.9')); ?>' id='cf7-style-frontend-script-js'></script>
	<script type='text/javascript' id='contact-form-7-js-extra'>
		/* <![CDATA[ */
		var wpcf7 = {"apiSettings":{"root":"https:\/\/www.jdkfashion.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
		/* ]]> */
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/contact-form-7/includes/js/scriptsde54.html?ver=5.3')); ?>' id='contact-form-7-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/google-language-translator/js/scripts8bc9.js?ver=6.0.7')); ?>' id='scripts-js'></script>
	<script type='text/javascript' src='../translate.google.com/translate_a/elementcd15.html?cb=GoogleLanguageTranslatorInit' id='scripts-google-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70')); ?>' id='jquery-blockui-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min6b25.js?ver=2.1.4')); ?>' id='js-cookie-js'></script>
	<script type='text/javascript' id='woocommerce-js-extra'>
		/* <![CDATA[ */
		var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
		/* ]]> */
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min1c9b.js?ver=4.6.1')); ?>' id='woocommerce-js'></script>
	<script type='text/javascript' id='wc-cart-fragments-js-extra'>
		/* <![CDATA[ */
		var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_c05281566f5124249e48b956e30fd33f","fragment_name":"wc_fragments_c05281566f5124249e48b956e30fd33f","request_timeout":"5000"};
		/* ]]> */
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min1c9b.js?ver=4.6.1')); ?>' id='wc-cart-fragments-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/themes/sydney/js/scriptsd03b.js?ver=5.5.1')); ?>' id='sydney-scripts-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/themes/sydney/js/main2e1f.js?ver=20200504')); ?>' id='sydney-main-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/themes/sydney/js/so-legacyd03b.js?ver=5.5.1')); ?>' id='sydney-so-legacy-scripts-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/themes/sydney/js/so-legacy-maind03b.js?ver=5.5.1')); ?>' id='sydney-so-legacy-main-js'></script>
	<script type='text/javascript' id='wce_frontend_js-js-extra'>
		/* <![CDATA[ */
		var catalog_enquiry_front = {"ajaxurl":"https:\/\/www.jdkfashion.com\/wp-admin\/admin-ajax.php","json_arr":"[\"name\",\"email\",\"subject\",\"phone\",\"address\",\"comment\",\"fileupload\"]","settings":{"is_page_redirect":"Enable","redirect_page_id":"480","custom_static_heading":"","name_label":"Your Name","email_label":"Your Email","subject_label":"Subject of Enquiry","phone_label":"Your Cellphone Number","address_label":"Give Your Address","comment_label":"Your Message","fileupload_label":"Upload File (Maximum 2MB)","captcha_label":"","captcha_input_label":"","is_captcha":"Enable","is_enable":"Enable","for_user_type":"3","other_emails":"","top_content_form":"","bottom_content_form":"","is_enable_enquiry":"Enable","button_type":"0","button_link":"","button_text":"","button_text_color":"fbfbfb","button_background_color":"fbfbfb","button_text_color_hover":"fbfbfb","button_background_color_hover":"fbfbfb","button_border_color":"fbfbfb","is_subject":"Enable","is_phone":"Enable","is_address":"Enable","is_comment":"Enable","is_fileupload":"Enable","filesize_limit":"2","other_admin_mail":""},"error_levels":{"name_required":"Name is required field","email_required":"Email is required field","email_valid":"Please Enter Valid Email Id","captcha_required":"Please enter the security code","captcha_valid":"Please enter the valid seurity code","ajax_error":"Error in system please try later","filetype_error":"Invalid file format.","filesize_error":"Exceeded filesize limit."},"ajax_success_msg":"Enquiry sent successfully","redirect_link":"https:\/\/www.jdkfashion.com\/enquiry\/","captcha":"1UZ5TD1W"};
		/* ]]> */
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/woocommerce-catalog-enquiry/assets/frontend/js/frontendee9a.js?ver=3.2.2')); ?>' id='wce_frontend_js-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-includes/js/wp-embed.mind03b.js?ver=5.5.1' )); ?>' id='wp-embed-js'></script>
	<script type='text/javascript' id='siteorigin-panels-front-styles-js-extra'>
		/* <![CDATA[ */
		var panelsStyles = {"fullContainer":"body"};
		/* ]]> */
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-content/plugins/siteorigin-panels/js/styling.mind731.js?ver=2.11.5')); ?>' id='siteorigin-panels-front-styles-js'></script>
	<script type='text/javascript' id='mediaelement-core-js-before'>
		var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-includes/js/mediaelement/mediaelement-and-player.minc270.js?ver=4.2.13-9993131')); ?>' id='mediaelement-core-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-includes/js/mediaelement/mediaelement-migrate.mind03b.js?ver=5.5.1')); ?>' id='mediaelement-migrate-js'></script>
	<script type='text/javascript' id='mediaelement-js-extra'>
		/* <![CDATA[ */
		var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
		/* ]]> */
	</script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-includes/js/mediaelement/wp-mediaelement.mind03b.js?ver=5.5.1')); ?>' id='wp-mediaelement-js'></script>
	<script type='text/javascript' src='<?php echo e(asset('frontend/wp-includes/js/mediaelement/renderers/vimeo.minc270.js?ver=4.2.13-9993131')); ?>' id='mediaelement-vimeo-js'></script>
	<!-- TC Custom JavaScript -->
	<script type="text/javascript">;(function($) {

	if( $('#contact,#c2,#c3 .contact-address').length ) {

		var address     = $('#contact .contact-address').text();
		var addressArr  = address.split("//");
		var newAddress  = addressArr.join("<br/>");

		$('#contact .contact-address').text('');
		$('#contact .contact-address').append('<span><i class="fa fa-home"></i></span>'+'<div class="address-lines">'+newAddress+'</div>');
	/*
		// Second phone 
		var phoneNumber = 'Fax # 0088-02-8410587';
		var phoneHTML   = '<div class="contact-phone"><span><i class="fa fa-phone"></i></span>'+phoneNumber+'</div>';
		$('#contact .contact-phone').after(phoneHTML);
	*/
		// Extra email 
		var emailNumber_1 = 'arif@jdkfashion.com';
		var emailNumber_2 = 'hanif@jdkfashion.com';
		var emailNumber_3 = 'chris@jdkfashion.com';
		var emailHTML   = '<div class="contact-email"><span><i class="fa fa-envelope"></i></span><a href="mailto:arif@jdkfashion.com">'+emailNumber_1+'</a></div><div class="contact-email"><span><i class="fa fa-envelope"></i></span><a href="mailto:hanif@jdkfashion.com">'+emailNumber_2+'</a></div><div class="contact-email"><span><i class="fa fa-envelope"></i></span><a href="mailto:chris@jdkfashion.com">'+emailNumber_3+'</a></div>';
		$('#contact .contact-email').after(emailHTML);
		
		var emailHTML_Sp = '<div class="contact-email"><span><i class="fa fa-envelope"></i></span><a href="mailto:chris@jdkfashion.com">'+emailNumber_3+'</a></div>';
		$('#c3 .contact-email').after(emailHTML_Sp);
		
		var emailHTML_US = '<div class="contact-email"><span><i class="fa fa-envelope"></i></span><a href="mailto:chris@jdkfashion.com">'+emailNumber_3+'</a></div>';
		$('#c2 .contact-email').after(emailHTML_US);
		
	}

	})(jQuery);
	</script>	
	<script>
		(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	<script type="text/javascript">document.body.className = document.body.className.replace("siteorigin-panels-before-js","");</script><?php /**PATH C:\xampp\htdocs\git\resources\views/frontend/partials/script.blade.php ENDPATH**/ ?>
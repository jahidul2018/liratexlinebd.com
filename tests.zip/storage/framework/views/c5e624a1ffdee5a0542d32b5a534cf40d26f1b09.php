<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from www.jdkfashion.com/products/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Oct 2020 05:35:11 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="../xmlrpc.html">

<title>Products &#8211; Lira textile.</title>

<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.jdkfashion.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.1"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='sydney-wc-css-css'  href='<?php echo e(asset('/frontend/wp-content/themes/sydney/woocommerce/css/wcd03b.css?ver=5.5.1')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='sydney-bootstrap-css'  href='<?php echo e(asset('/frontend/wp-content/themes/sydney/css/bootstrap/bootstrap.min68b3.css?ver=1')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='<?php echo e(asset('/frontend/wp-includes/css/dist/block-library/style.mind03b.css?ver=5.5.1')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style6b00.css?ver=3.4.0')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style6b00.css?ver=3.4.0')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='cf7-style-frontend-style-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/contact-form-7-style/css/frontend20f0.html?ver=3.1.9')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='cf7-style-responsive-style-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/contact-form-7-style/css/responsive20f0.css?ver=3.1.9')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/contact-form-7/includes/css/stylesde54.html?ver=5.3')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='google-language-translator-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/google-language-translator/css/style8bc9.css?ver=6.0.7')); ?>' type='text/css' media='' />
<link rel='stylesheet' id='glt-toolbar-styles-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/google-language-translator/css/toolbar8bc9.css?ver=6.0.7')); ?>' type='text/css' media='' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/assets/css/woocommerce-layout1c9b.css?ver=4.6.1')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen1c9b.css?ver=4.6.1')); ?>' type='text/css' media='only screen and (max-width: 768px)' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='parent-style-css'  href='<?php echo e(asset('/frontend/wp-content/themes/sydney/styled03b.css?ver=5.5.1')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='sydney-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Rubik%3A400%2C600%7CRaleway%3A600&amp;subset=latin&amp;display=swap' type='text/css' media='all' />
<link rel='stylesheet' id='sydney-style-css'  href='<?php echo e(asset('/frontend/wp-content/themes/sydney-child/style1c5d.css?ver=20200129')); ?>' type='text/css' media='all' />
<style id='sydney-style-inline-css' type='text/css'>
body, #mainnav ul ul a { font-family:Rubik;}
h1, h2, h3, h4, h5, h6, #mainnav ul li a, .portfolio-info, .roll-testimonials .name, .roll-team .team-content .name, .roll-team .team-item .team-pop .name, .roll-tabs .menu-tab li a, .roll-testimonials .name, .roll-project .project-filter li a, .roll-button, .roll-counter .name-count, .roll-counter .numb-count button, input[type="button"], input[type="reset"], input[type="submit"] { font-family:Raleway;}
.site-title { font-size:32px; }
.site-description { font-size:16px; }
#mainnav ul li a { font-size:24px; }
h1 { font-size:52px; }
h2 { font-size:42px; }
h3 { font-size:32px; }
h4 { font-size:25px; }
h5 { font-size:20px; }
h6 { font-size:18px; }
body { font-size:15px; }
.single .hentry .title-post { font-size:32px; }
.header-image { background-size:cover;}
.header-image { height:150px; }
.llms-student-dashboard .llms-button-secondary:hover,.llms-button-action:hover,.read-more-gt,.widget-area .widget_fp_social a,#mainnav ul li a:hover, .sydney_contact_info_widget span, .roll-team .team-content .name,.roll-team .team-item .team-pop .team-social li:hover a,.roll-infomation li.address:before,.roll-infomation li.phone:before,.roll-infomation li.email:before,.roll-testimonials .name,.roll-button.border,.roll-button:hover,.roll-icon-list .icon i,.roll-icon-list .content h3 a:hover,.roll-icon-box.white .content h3 a,.roll-icon-box .icon i,.roll-icon-box .content h3 a:hover,.switcher-container .switcher-icon a:focus,.go-top:hover,.hentry .meta-post a:hover,#mainnav > ul > li > a.active, #mainnav > ul > li > a:hover, button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, .text-color, .social-menu-widget a, .social-menu-widget a:hover, .archive .team-social li a, a, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,.classic-alt .meta-post a,.single .hentry .meta-post a, .content-area.modern .hentry .meta-post span:before, .content-area.modern .post-cat { color:#dd0000}
.llms-student-dashboard .llms-button-secondary,.llms-button-action,.reply,.woocommerce #respond input#submit,.woocommerce a.button,.woocommerce button.button,.woocommerce input.button,.project-filter li a.active, .project-filter li a:hover,.preloader .pre-bounce1, .preloader .pre-bounce2,.roll-team .team-item .team-pop,.roll-progress .progress-animate,.roll-socials li a:hover,.roll-project .project-item .project-pop,.roll-project .project-filter li.active,.roll-project .project-filter li:hover,.roll-button.light:hover,.roll-button.border:hover,.roll-button,.roll-icon-box.white .icon,.owl-theme .owl-controls .owl-page.active span,.owl-theme .owl-controls.clickable .owl-page:hover span,.go-top,.bottom .socials li:hover a,.sidebar .widget:before,.blog-pagination ul li.active,.blog-pagination ul li:hover a,.content-area .hentry:after,.text-slider .maintitle:after,.error-wrap #search-submit:hover,#mainnav .sub-menu li:hover > a,#mainnav ul li ul:after, button, input[type="button"], input[type="reset"], input[type="submit"], .panel-grid-cell .widget-title:after { background-color:#dd0000}
.llms-student-dashboard .llms-button-secondary,.llms-student-dashboard .llms-button-secondary:hover,.llms-button-action,.llms-button-action:hover,.roll-socials li a:hover,.roll-socials li a,.roll-button.light:hover,.roll-button.border,.roll-button,.roll-icon-list .icon,.roll-icon-box .icon,.owl-theme .owl-controls .owl-page span,.comment .comment-detail,.widget-tags .tag-list a:hover,.blog-pagination ul li,.hentry blockquote,.error-wrap #search-submit:hover,textarea:focus,input[type="text"]:focus,input[type="password"]:focus,input[type="datetime"]:focus,input[type="datetime-local"]:focus,input[type="date"]:focus,input[type="month"]:focus,input[type="time"]:focus,input[type="week"]:focus,input[type="number"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="search"]:focus,input[type="tel"]:focus,input[type="color"]:focus, button, input[type="button"], input[type="reset"], input[type="submit"], .archive .team-social li a { border-color:#dd0000}
.go-top:hover svg,.sydney_contact_info_widget span { fill:#dd0000;}
.site-header.float-header { background-color:rgba(2,2,2,0.9);}
@media  only screen and (max-width: 1024px) { .site-header { background-color:#020202;}}
.site-title a, .site-title a:hover { color:#ffffff}
.site-description { color:#ffffff}
#mainnav ul li a, #mainnav ul li::before { color:#ffffff}
#mainnav .sub-menu li a { color:#ffffff}
#mainnav .sub-menu li a { background:#1c0c0c}
.text-slider .maintitle, .text-slider .subtitle { color:#ffffff}
body { color:#110000}
#secondary { background-color:#ffffff}
#secondary, #secondary a { color:#ba3700}
.footer-widgets { background-color:#dddddd}
#sidebar-footer,#sidebar-footer a,.footer-widgets .widget-title { color:#ba3700}
.btn-menu .sydney-svg-icon { fill:#ffffff}
#mainnav ul li a:hover { color:#59d600}
.site-footer { background-color:#1c1c1c}
.site-footer,.site-footer a { color:#1e73be}
.overlay { background-color:#202020}
.page-wrap { padding-top:0px;}
.page-wrap { padding-bottom:0px;}
@media  only screen and (max-width: 1025px) {		
			.mobile-slide {
				display: block;
			}
			.slide-item {
				background-image: none !important;
			}
			.header-slider {
			}
			.slide-item {
				height: auto !important;
			}
			.slide-inner {
				min-height: initial;
			} 
		}
@media  only screen and (max-width: 780px) { 
    	h1 { font-size: 32px;}
		h2 { font-size: 28px;}
		h3 { font-size: 22px;}
		h4 { font-size: 18px;}
		h5 { font-size: 16px;}
		h6 { font-size: 14px;}
	}

</style>
<!--[if lte IE 9]>
<link rel='stylesheet' id='sydney-ie9-css'  href='https://www.jdkfashion.com/wp-content/themes/sydney/css/ie9.css?ver=5.5.1' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='sydney-font-awesome-css'  href='<?php echo e(asset('/frontend/wp-content/themes/sydney/fonts/font-awesome.mind03b.css?ver=5.5.1')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='wce_frontend_css-css'  href='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce-catalog-enquiry/assets/frontend/css/frontendee9a.css?ver=3.2.2')); ?>' type='text/css' media='all' />
<style id='wce_frontend_css-inline-css' type='text/css'>

	            .woo_catalog_enquiry_custom_button_enquiry {
					background: #003366;
					color: #fbfbfb;
					padding: 10px;
					width: 200px;
					height: 50px;
					line-height: 18px;
					border-radius: 5px;
					border: 1px solid #fbfbfb;
					font-size: 18px;
					margin-top : 0px;
					margin-bottom : 0px;
				
				}
				.woo_catalog_enquiry_custom_button_enquiry:hover {
					background: #fbfbfb;
					color: #0099cc;
				}
				#woo_catalog_enquiry_custom_button {
					background: #fbfbfb;
					color: #fbfbfb;
					padding: 5px;
					width: 80px;
					height: 26px;
					line-height: 14px;
					border-radius: 5px;
					border: #fbfbfb;
					font-size: 12px;
					margin-top: 5px;
					margin-bottom: 5px;
					
				}
				#woo_catalog_enquiry_custom_button:hover {
					background: #fbfbfb;
					color: #fbfbfb;
				}
				/* The Modal (background) */
				#woo_catalog .catalog_modal {
				    display: none; /* Hidden by default */
				    position: fixed; /* Stay in place */
				    z-index: 100000; /* Sit on top */
				    /*padding-top: 100px;*/ /* Location of the box */
				    left: 0;
				    top: 0;
				    width: 100%; /* Full width */
				    height: 100%; /* Full height */
				    overflow: auto; /* Enable scroll if needed */
				    background-color: rgb(0,0,0); /* Fallback color */
				    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
				}
</style>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp')); ?>' id='jquery-core-js'></script>
<link rel="https://api.w.org/" href="" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="../xmlrpc0db0.html?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.5.1" />
<meta name="generator" content="WooCommerce 4.6.1" />
<style type="text/css">p.hello { font-size:12px; color:darkgray; }#google_language_translator, #flags { text-align:left; }#google_language_translator { clear:both; }#flags { width:165px; }#flags a { display:inline-block; margin-right:2px; }#google_language_translator a {display: none !important; }.goog-te-gadget {color:transparent !important;}.goog-te-gadget { font-size:0px !important; }.goog-branding { display:none; }.goog-tooltip {display: none !important;}.goog-tooltip:hover {display: none !important;}.goog-text-highlight {background-color: transparent !important; border: none !important; box-shadow: none !important;}#google_language_translator select.goog-te-combo { color:#32373c; }.goog-te-banner-frame{visibility:hidden !important;}body { top:0px !important;}#glt-translate-trigger { left:50%; margin-left:-63px; right:auto; }#glt-translate-trigger > span { color:#ffffff; }#glt-translate-trigger { background:#f89406; }.goog-te-gadget .goog-te-combo { width:100%; }</style><script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})("");
</script>			<style>
				.sydney-svg-icon {
					display: inline-block;
					width: 16px;
					height: 16px;
					vertical-align: middle;
					line-height: 1;
				}
				.team-item .team-social li .sydney-svg-icon {
					fill: #fff;
				}
				.team-item .team-social li:hover .sydney-svg-icon {
					fill: #000;
				}
				.team_hover_edits .team-social li a .sydney-svg-icon {
					fill: #000;
				}
				.team_hover_edits .team-social li:hover a .sydney-svg-icon {
					fill: #fff;
				}				
			</style>
			<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	
<style class='cf7-style' media='screen' type='text/css'>
body .cf7-style.transparent-two-columns,body .cf7-style.transparent-two-columns input[type='submit'] {font-family: 'Rubik',sans-serif;} 
</style>
	<style type="text/css">
		.header-image {
			background-image: url(../wp-content/uploads/cropped-united-nations-runway-3.jpg);
			display: block;
		}
		@media  only screen and (max-width: 1024px) {
			.header-inner {
				display: block;
			}
			.header-image {
				background-image: none;
				height: auto !important;
			}		
		}
	</style>
	<link rel="icon" href="<?php echo e(asset('/frontend/wp-content/uploads/jdk_transparent-100x100.png')); ?>" sizes="32x32" />
<link rel="icon" href="<?php echo e(asset('/frontend/wp-content/uploads/jdk_transparent.png')); ?>" sizes="192x192" />
<link rel="apple-touch-icon" href="<?php echo e(asset('/frontend/wp-content/uploads/jdk_transparent.png')); ?>" />
<meta name="msapplication-TileImage" content="https://www.jdkfashion.com/wp-content/uploads/jdk_transparent.png" />
		<style type="text/css" id="wp-custom-css">
			/* Address lines style */
.contact-address .address-lines {
  margin-top: -25px;
  margin-left: 28px;
}

/* Reduce footer widgets gap */
.footer-widgets .sidebar-column .widget{
  padding-top: 0;
  padding-bottom: 0;
}		</style>
		</head>

<body class="archive post-type-archive post-type-archive-product theme-sydney woocommerce woocommerce-page woocommerce-no-js menu-inline">

	<div class="preloader">
	    <div class="spinner">
	        <div class="pre-bounce1"></div>
	        <div class="pre-bounce2"></div>
	    </div>
	</div>
	
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	
	<header id="masthead" class="site-header" role="banner">
		<div class="header-wrap">
            <div class="container">
                <div class="row">
					<div class="col-md-4 col-sm-8 col-xs-12">
											<a href="" title="Lira textile."><img class="site-logo" src="<?php echo e(asset('/frontend/wp-content/uploads/oie_transparent-min.png')); ?>" alt="Lira textile." /></a>
																</div>
					<div class="col-md-8 col-sm-4 col-xs-12">
						<div class="btn-menu"><i class="sydney-svg-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z" /></svg></i></div>
						<nav id="mainnav" class="mainnav" role="navigation">
							<div class="menu-main-menu-container"><ul id="menu-main-menu" class="menu">
								<li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-42 current_page_item menu-item-44"><a href="<?php echo e(route('home')); ?>" aria-current="page">Home</a></li>
<li id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-41"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
<li id="menu-item-40" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item current_page_item menu-item-40"><a href="<?php echo e(route('product')); ?>" aria-current="page">Products</a></li>
<li id="menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-39"><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
</ul></div>						</nav><!-- #site-navigation -->
					</div>
				</div>
			</div>
		</div>
	</header><!-- #masthead -->

	
	<div class="sydney-hero-area">
				<div class="header-image">
			<div class="overlay"></div>																<img class="header-inner" src="<?php echo e(asset('/frontend/wp-content/uploads/cropped-united-nations-runway-3.jpg')); ?>" width="1920" alt="JDK Group Ltd." title="JDK Group Ltd.">
									</div>
		
			</div>

	
	<div id="content" class="page-wrap">
		<div class="container content-wrapper">
			<div class="row">	<div id="primary" class="content-area col-md-9"><main id="main" class="site-main" role="main"><nav class="woocommerce-breadcrumb"><a href="">Home</a>&nbsp;&#47;&nbsp;Products</nav><header class="woocommerce-products-header">
	<h3 class="archive-title">Men Products</h3>
	</header>
<div class="woocommerce-notices-wrapper"></div><p class="woocommerce-result-count">
	Showing all results</p>
<form class="woocommerce-ordering" method="get">
	<select name="orderby" class="orderby" aria-label="Shop order">
					<option value="menu_order"  selected='selected'>Default sorting</option>
					<option value="popularity" >Sort by popularity</option>
					<option value="date" >Sort by latest</option>
					<option value="price" >Sort by price: low to high</option>
					<option value="price-desc" >Sort by price: high to low</option>
			</select>
	<input type="hidden" name="paged" value="1" />
	</form>
<ul class="products columns-4">





<li class="product type-product post-433 status-publish first instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-grouped">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/1.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/2.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-431 status-publish instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/3.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-441 status-publish last instock product_cat-women product_tag-tops has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/4.jpg')); ?>"  class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>
<li class="product type-product post-433 status-publish first instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-grouped">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/5.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/6.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-431 status-publish instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/7.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-441 status-publish last instock product_cat-women product_tag-tops has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/8.jpg')); ?>"  class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>
<li class="product type-product post-433 status-publish first instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-grouped">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/9.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/10.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-431 status-publish instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/11.jpg')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-441 status-publish last instock product_cat-women product_tag-tops has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/13.jpg')); ?>"  class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>
<li class="product type-product post-433 status-publish first instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-grouped">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/14.png')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/15.png')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-431 status-publish instock product_cat-men product_tag-denim has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/17.png')); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"  sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>

<li class="product type-product post-441 status-publish last instock product_cat-women product_tag-tops has-post-thumbnail shipping-taxable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><div class="yith-placeholder"></div><img width="300" height="400" src="<?php echo e(asset('/frontend/Lira-tex/man/18.jpg')); ?>"  class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" sizes="(max-width: 300px) 100vw, 300px" /><h2 class="woocommerce-loop-product__title"></h2>
</a></li>





</ul>
</main></div>
<div id="secondary" class="widget-area col-md-3" role="complementary">
	<aside id="woocommerce_product_categories-2" class="widget woocommerce widget_product_categories">
        <h3 class="widget-title">Product categories</h3><ul class="product-categories">
            <li class="cat-item cat-item-24">
                <a href="<?php echo e(route('product-category-man')); ?>">Men</a> 
                <span class="count">(3)</span>
            </li>
<li class="cat-item cat-item-26">
    <a href="<?php echo e(route('product-category-women')); ?>">Women</a> 
    <span class="count">(6)</span>
</li>
</ul>
</aside>

</div><!-- #secondary -->
			</div>
		</div>
	</div><!-- #content -->

	
			

	

    <a class="go-top"><i class="fa fa-angle-up"></i></a>
		
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info container">
			&copy; 
			<a style="text-decoration: underline;" href="" rel="home">lira textile 2020</a>
			<span class="sep"> | </span>
			All rights reserved.
		</div><!-- .site-info -->
	</footer><!-- #colophon -->

	
</div><!-- #page -->

        <script>function GoogleLanguageTranslatorInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages:'zh-CN,en,fr,de,it,pt,es,tr', autoDisplay: false}, 'google_language_translator');}</script><script type="application/ld+json">{"@context":"https:\/\/schema.org\/","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"item":{"name":"Home","@id":"https:\/\/www.jdkfashion.com"}},{"@type":"ListItem","position":2,"item":{"name":"Products","@id":"https:\/\/www.jdkfashion.com\/products\/"}}]}</script>	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})()
	</script>
	                <style type="text/css" media="all"
                       id="siteorigin-panels-layouts-footer">/* Layout w5da4be2c1213f */ #pgc-w5da4be2c1213f-0-0 { width:100%;width:calc(100% - ( 0 * 30px ) ) } #pl-w5da4be2c1213f .so-panel , #pl-w5da4be2c1213f .so-panel:last-child { margin-bottom:0px } #pg-w5da4be2c1213f-0> .panel-row-style { padding:0px } #pg-w5da4be2c1213f-0.panel-no-style, #pg-w5da4be2c1213f-0.panel-has-style > .panel-row-style { -webkit-align-items:center;align-items:center } @media (max-width:780px){ #pg-w5da4be2c1213f-0.panel-no-style, #pg-w5da4be2c1213f-0.panel-has-style > .panel-row-style { -webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column } #pg-w5da4be2c1213f-0 > .panel-grid-cell , #pg-w5da4be2c1213f-0 > .panel-row-style > .panel-grid-cell { width:100%;margin-right:0 } #pg-w5da4be2c1213f-0 { margin-bottom:px } #pl-w5da4be2c1213f .panel-grid-cell { padding:0 } #pl-w5da4be2c1213f .panel-grid .panel-grid-cell-empty { display:none } #pl-w5da4be2c1213f .panel-grid .panel-grid-cell-mobile-last { margin-bottom:0px }  } </style><link rel='stylesheet' id='siteorigin-panels-front-css'  href='../wp-content/plugins/siteorigin-panels/css/front-flex.mind731.css?ver=2.11.5' type='text/css' media='all' />
<script type='text/javascript' src='/frontend/wp-content/plugins/contact-form-7-style/js/frontend-min20f0.html?ver=3.1.9' id='cf7-style-frontend-script-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":""},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/contact-form-7/includes/js/scriptsde54.html?ver=5.3')); ?>' id='contact-form-7-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/google-language-translator/js/scripts8bc9.js?ver=6.0.7')); ?>' id='scripts-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/../translate.google.com/translate_a/elementcd15.html?cb=GoogleLanguageTranslatorInit')); ?>' id='scripts-google-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70')); ?>' id='jquery-blockui-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min6b25.js?ver=2.1.4')); ?>' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min1c9b.js?ver=4.6.1')); ?>' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_c05281566f5124249e48b956e30fd33f","fragment_name":"wc_fragments_c05281566f5124249e48b956e30fd33f","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min1c9b.js?ver=4.6.1')); ?>' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/themes/sydney/js/scriptsd03b.js?ver=5.5.1')); ?>' id='sydney-scripts-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/themes/sydney/js/main2e1f.js?ver=20200504')); ?>' id='sydney-main-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/themes/sydney/js/so-legacyd03b.js?ver=5.5.1')); ?>' id='sydney-so-legacy-scripts-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/themes/sydney/js/so-legacy-maind03b.js?ver=5.5.1')); ?>' id='sydney-so-legacy-main-js'></script>
<script type='text/javascript' id='wce_frontend_js-js-extra'>
/* <![CDATA[ */
var catalog_enquiry_front = {"ajaxurl":"https:\/\/www.jdkfashion.com\/wp-admin\/admin-ajax.php","json_arr":"[\"name\",\"email\",\"subject\",\"phone\",\"address\",\"comment\",\"fileupload\"]","settings":{"is_page_redirect":"Enable","redirect_page_id":"480","custom_static_heading":"","name_label":"Your Name","email_label":"Your Email","subject_label":"Subject of Enquiry","phone_label":"Your Cellphone Number","address_label":"Give Your Address","comment_label":"Your Message","fileupload_label":"Upload File (Maximum 2MB)","captcha_label":"","captcha_input_label":"","is_captcha":"Enable","is_enable":"Enable","for_user_type":"3","other_emails":"","top_content_form":"","bottom_content_form":"","is_enable_enquiry":"Enable","button_type":"0","button_link":"","button_text":"","button_text_color":"fbfbfb","button_background_color":"fbfbfb","button_text_color_hover":"fbfbfb","button_background_color_hover":"fbfbfb","button_border_color":"fbfbfb","is_subject":"Enable","is_phone":"Enable","is_address":"Enable","is_comment":"Enable","is_fileupload":"Enable","filesize_limit":"2","other_admin_mail":""},"error_levels":{"name_required":"Name is required field","email_required":"Email is required field","email_valid":"Please Enter Valid Email Id","captcha_required":"Please enter the security code","captcha_valid":"Please enter the valid seurity code","ajax_error":"Error in system please try later","filetype_error":"Invalid file format.","filesize_error":"Exceeded filesize limit."},"ajax_success_msg":"Enquiry sent successfully","redirect_link":"https:\/\/www.jdkfashion.com\/enquiry\/","captcha":"A30OIG8Y"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-content/plugins/woocommerce-catalog-enquiry/assets/frontend/js/frontendee9a.js?ver=3.2.2')); ?>' id='wce_frontend_js-js'></script>
<script type='text/javascript' src='<?php echo e(asset('/frontend/wp-includes/js/wp-embed.mind03b.js?ver=5.5.1')); ?>' id='wp-embed-js'></script>
<!-- TC Custom JavaScript --><script type="text/javascript">;(function($) {

  if( $('#contact,#c2,#c3 .contact-address').length ) {

      var address     = $('#contact .contact-address').text();
      var addressArr  = address.split("//");
      var newAddress  = addressArr.join("<br/>");

      $('#contact .contact-address').text('');
      $('#contact .contact-address').append('<span><i class="fa fa-home"></i></span>'+'<div class="address-lines">'+newAddress+'</div>');
/*
      // Second phone 
      var phoneNumber = 'Fax # 0088-02-8410587';
      var phoneHTML   = '<div class="contact-phone"><span><i class="fa fa-phone"></i></span>'+phoneNumber+'</div>';
      $('#contact .contact-phone').after(phoneHTML);
*/

    
  }

})(jQuery);</script>	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	
</body>

<!-- Mirrored from www.jdkfashion.com/products/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Oct 2020 05:35:17 GMT -->
</html>
<?php /**PATH /home/betasoft/public_html/liratext/resources/views/frontend/pages/product/productcategory/men/index.blade.php ENDPATH**/ ?>
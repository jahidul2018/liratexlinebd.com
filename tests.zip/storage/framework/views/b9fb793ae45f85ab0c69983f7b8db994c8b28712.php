<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from www.jdkfashion.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Oct 2020 05:34:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="xmlrpc.html">
    <title>Lira textile</title>
    <?php echo $__env->yieldContent('title'); ?>
    <?php echo $__env->make('frontend.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="home page-template page-template-page-templates page-template-page_front-page page-template-page-templatespage_front-page-php page page-id-42 theme-sydney siteorigin-panels siteorigin-panels-before-js siteorigin-panels-home woocommerce-no-js menu-inline">
	<?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
    <div id="content" class="page-wrap">  

            <?php echo $__env->yieldContent('content'); ?>
            
        </div><!-- #content -->
        
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
    
	</div><!-- #page -->
<?php echo $__env->make('frontend.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>
</body>
<!-- Mirrored from www.jdkfashion.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Oct 2020 05:34:50 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\git\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>
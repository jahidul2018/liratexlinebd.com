<div id="sidebar-footer" class="footer-widgets widget-area" role="complementary">
    <div class="container">
        <div class="sidebar-column col-md-6">
            <aside id="text-2" class="widget widget_text">
                <h3 class="widget-title">Company Summary</h3>			
                <div class="textwidget">
                    <p>Lira Texline BD is an APPAREL BUYING HOUSE & Manufactures specialized in providing customized service to buyers with Sourcing, Merchandising, Quality Control, Product Development and assuring Compliance Issues for products manufactured for USA and EEC market. We are experiencing tremendous growth in terms of expanding the operational capacity and building up a strong marketing network all over USA, EEC and the Far East. Moreover, we are always dedicated for our valuable Buyer’s as well as we have keep in touch with our Buyer’s to get good outcome & avoid any kind of misunderstanding. We try to give feedback to our Buyers @ 24/7. Thanks </p>
                </div>
            </aside>				
        </div>
        <div class="sidebar-column col-md-6">
            <aside id="text-2" class="widget widget_text">
                <h3 class="widget-title">Lira Texline BD.</h3>			
                <div class="textwidget">
                    <p>House#40, Flat-B2, Road# 18, Sector-11, Uttara,<br/>
                    Dhaka-1230, Bangladesh.<br/>
                    Land Phone: 0088-02-8411167<br/>
                    Emergency Cell @ +8801677577142<br/>
                    Email @: liton@liratexlinebd.com<br/>
                    Email @: jishan@liratexlinebd.com<br/>
                    Email @: info@liratexlinebd.com <br/>
                    </p>
                </div>
            </aside>				
        </div>
    </div>	
</div>	
<a class="go-top"><i class="fa fa-angle-up"></i></a>	

<footer id="colophon" class="site-footer" role="contentinfo">
    <div class="site-info container text-center">
        &copy; 
        <a style="text-decoration: underline;" href="" rel="home">Lira text. 2020|| </a><a style="text-decoration: underline;" href="https://www.betasoftltd.com" rel="home">Powered by betaSoftltd</a>
        <span class="sep"> | </span>
        All rights reserved.
    </div><!-- .site-info -->
</footer><!-- #colophon -->
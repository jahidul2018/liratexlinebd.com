
	<link rel='dns-prefetch' href='http://translate.google.com/' />
	<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
	<link rel='dns-prefetch' href='http://s.w.org/' />
	<link rel="alternate" type="application/rss+xml" title="JDK Group Ltd. &raquo; Feed" href="feed/index.html" />
	<link rel="alternate" type="application/rss+xml" title="JDK Group Ltd. &raquo; Comments Feed" href="comments/feed/index.html" />
	<script type="text/javascript">
		window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.jdkfashion.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.1"}};
		!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
	</script>
	<style type="text/css">
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 .07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>

	<link rel='stylesheet' id='sydney-wc-css-css'  href='{{ asset('frontend/wp-content/themes/sydney/woocommerce/css/wcd03b.css?ver=5.5.1') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='sydney-bootstrap-css'  href='{{ asset('frontend/wp-content/themes/sydney/css/bootstrap/bootstrap.min68b3.css?ver=1') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='wp-block-library-css'  href='{{ asset('frontend/wp-includes/css/dist/block-library/style.mind03b.css?ver=5.5.1') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='wc-block-vendors-style-css'  href='{{ asset('frontend/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style6b00.css?ver=3.4.0') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='wc-block-style-css'  href='{{ asset('frontend/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style6b00.css?ver=3.4.0') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='cf7-style-frontend-style-css'  href='{{ asset('frontend/wp-content/plugins/contact-form-7-style/css/frontend20f0.html?ver=3.1.9') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='cf7-style-responsive-style-css'  href='{{ asset('frontend/wp-content/plugins/contact-form-7-style/css/responsive20f0.css?ver=3.1.9') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='contact-form-7-css'  href='{{ asset('frontend/wp-content/plugins/contact-form-7/includes/css/stylesde54.html?ver=5.3') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='google-language-translator-css'  href='{{ asset('frontend/wp-content/plugins/google-language-translator/css/style8bc9.css?ver=6.0.7') }}' type='text/css' media='' />
	<link rel='stylesheet' id='glt-toolbar-styles-css'  href='{{ asset('frontend/wp-content/plugins/google-language-translator/css/toolbar8bc9.css?ver=6.0.7') }}' type='text/css' media='' />
	<link rel='stylesheet' id='siteorigin-panels-front-css'  href='{{ asset('frontend/wp-content/plugins/siteorigin-panels/css/front-flex.mind731.css?ver=2.11.5') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='woocommerce-layout-css'  href='{{ asset('frontend/wp-content/plugins/woocommerce/assets/css/woocommerce-layout1c9b.css?ver=4.6.1') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='{{ asset('frontend/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen1c9b.css?ver=4.6.1') }}' type='text/css' media='only screen and (max-width: 768px)' />
	<style id='woocommerce-inline-inline-css' type='text/css'>
	.woocommerce form .form-row .required { visibility: visible; }
	</style>
	<link rel='stylesheet' id='parent-style-css'  href='{{ asset('frontend/wp-content/themes/sydney/styled03b.css?ver=5.5.1') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='sydney-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Rubik%3A400%2C600%7CRaleway%3A600&amp;subset=latin&amp;display=swap' type='text/css' media='all' />
	<link rel='stylesheet' id='sydney-style-css'  href='{{ asset('frontend/wp-content/themes/sydney-child/style1c5d.css?ver=20200129') }}' type='text/css' media='all' />
	<style id='sydney-style-inline-css' type='text/css'>

		body, #mainnav ul ul a { font-family:Rubik;}
		h1, h2, h3, h4, h5, h6, #mainnav ul li a, .portfolio-info, .roll-testimonials .name, .roll-team .team-content .name, .roll-team .team-item .team-pop .name, .roll-tabs .menu-tab li a, .roll-testimonials .name, .roll-project .project-filter li a, .roll-button, .roll-counter .name-count, .roll-counter .numb-count button, input[type="button"], input[type="reset"], input[type="submit"] { font-family:Raleway;}
		.site-title { font-size:32px; }
		.site-description { font-size:16px; }
		#mainnav ul li a { font-size:24px; }
		h1 { font-size:52px; }
		h2 { font-size:42px; }
		h3 { font-size:32px; }
		h4 { font-size:25px; }
		h5 { font-size:20px; }
		h6 { font-size:18px; }
		body { font-size:15px; }
		.single .hentry .title-post { font-size:32px; }
		.header-image { background-size:cover;}
		.header-image { height:150px; }
		.llms-student-dashboard .llms-button-secondary:hover,.llms-button-action:hover,.read-more-gt,.widget-area .widget_fp_social a,#mainnav ul li a:hover, .sydney_contact_info_widget span, .roll-team .team-content .name,.roll-team .team-item .team-pop .team-social li:hover a,.roll-infomation li.address:before,.roll-infomation li.phone:before,.roll-infomation li.email:before,.roll-testimonials .name,.roll-button.border,.roll-button:hover,.roll-icon-list .icon i,.roll-icon-list .content h3 a:hover,.roll-icon-box.white .content h3 a,.roll-icon-box .icon i,.roll-icon-box .content h3 a:hover,.switcher-container .switcher-icon a:focus,.go-top:hover,.hentry .meta-post a:hover,#mainnav > ul > li > a.active, #mainnav > ul > li > a:hover, button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, .text-color, .social-menu-widget a, .social-menu-widget a:hover, .archive .team-social li a, a, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,.classic-alt .meta-post a,.single .hentry .meta-post a, .content-area.modern .hentry .meta-post span:before, .content-area.modern .post-cat { color:#dd0000}
		.llms-student-dashboard .llms-button-secondary,.llms-button-action,.reply,.woocommerce #respond input#submit,.woocommerce a.button,.woocommerce button.button,.woocommerce input.button,.project-filter li a.active, .project-filter li a:hover,.preloader .pre-bounce1, .preloader .pre-bounce2,.roll-team .team-item .team-pop,.roll-progress .progress-animate,.roll-socials li a:hover,.roll-project .project-item .project-pop,.roll-project .project-filter li.active,.roll-project .project-filter li:hover,.roll-button.light:hover,.roll-button.border:hover,.roll-button,.roll-icon-box.white .icon,.owl-theme .owl-controls .owl-page.active span,.owl-theme .owl-controls.clickable .owl-page:hover span,.go-top,.bottom .socials li:hover a,.sidebar .widget:before,.blog-pagination ul li.active,.blog-pagination ul li:hover a,.content-area .hentry:after,.text-slider .maintitle:after,.error-wrap #search-submit:hover,#mainnav .sub-menu li:hover > a,#mainnav ul li ul:after, button, input[type="button"], input[type="reset"], input[type="submit"], .panel-grid-cell .widget-title:after { background-color:#dd0000}
		.llms-student-dashboard .llms-button-secondary,.llms-student-dashboard .llms-button-secondary:hover,.llms-button-action,.llms-button-action:hover,.roll-socials li a:hover,.roll-socials li a,.roll-button.light:hover,.roll-button.border,.roll-button,.roll-icon-list .icon,.roll-icon-box .icon,.owl-theme .owl-controls .owl-page span,.comment .comment-detail,.widget-tags .tag-list a:hover,.blog-pagination ul li,.hentry blockquote,.error-wrap #search-submit:hover,textarea:focus,input[type="text"]:focus,input[type="password"]:focus,input[type="datetime"]:focus,input[type="datetime-local"]:focus,input[type="date"]:focus,input[type="month"]:focus,input[type="time"]:focus,input[type="week"]:focus,input[type="number"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="search"]:focus,input[type="tel"]:focus,input[type="color"]:focus, button, input[type="button"], input[type="reset"], input[type="submit"], .archive .team-social li a { border-color:#dd0000}
		.go-top:hover svg,.sydney_contact_info_widget span { fill:#dd0000;}
		.site-header.float-header { background-color:rgba(2,2,2,0.9);}
		@media only screen and (max-width: 1024px) { .site-header { background-color:#020202;}}
		.site-title a, .site-title a:hover { color:#ffffff}
		.site-description { color:#ffffff}
		#mainnav ul li a, #mainnav ul li::before { color:#ffffff}
		#mainnav .sub-menu li a { color:#ffffff}
		#mainnav .sub-menu li a { background:#1c0c0c}
		.text-slider .maintitle, .text-slider .subtitle { color:#ffffff}
		body { color:#110000}
		#secondary { background-color:#ffffff}
		#secondary, #secondary a { color:#ba3700}
		.footer-widgets { background-color:#dddddd}
		#sidebar-footer,#sidebar-footer a,.footer-widgets .widget-title { color:#ba3700}
		.btn-menu .sydney-svg-icon { fill:#ffffff}
		#mainnav ul li a:hover { color:#59d600}
		.site-footer { background-color:#1c1c1c}
		.site-footer,.site-footer a { color:#1e73be}
		.overlay { background-color:#202020}
		.page-wrap { padding-top:0px;}
		.page-wrap { padding-bottom:0px;}
		@media only screen and (max-width: 1025px) {		
					.mobile-slide {
						display: block;
					}
					.slide-item {
						background-image: none !important;
					}
					.header-slider {
					}
					.slide-item {
						height: auto !important;
					}
					.slide-inner {
						min-height: initial;
					} 
				}
		@media only screen and (max-width: 780px) { 
				h1 { font-size: 32px;}
				h2 { font-size: 28px;}
				h3 { font-size: 22px;}
				h4 { font-size: 18px;}
				h5 { font-size: 16px;}
				h6 { font-size: 14px;}
		}


	</style>

	<link rel='stylesheet' id='sydney-font-awesome-css'  href='{{ asset('frontend/wp-content/themes/sydney/fonts/font-awesome.mind03b.css?ver=5.5.1') }}' type='text/css' media='all' />
	<link rel='stylesheet' id='wce_frontend_css-css'  href='{{ asset('frontend/wp-content/plugins/woocommerce-catalog-enquiry/assets/frontend/css/frontendee9a.css?ver=3.2.2') }}' type='text/css' media='all' />
<style id='wce_frontend_css-inline-css' type='text/css'>
		.woo_catalog_enquiry_custom_button_enquiry {
			background: #003366;
			color: #fbfbfb;
			padding: 10px;
			width: 200px;
			height: 50px;
			line-height: 18px;
			border-radius: 5px;
			border: 1px solid #fbfbfb;
			font-size: 18px;
			margin-top : 0px;
			margin-bottom : 0px;
		
		}
		.woo_catalog_enquiry_custom_button_enquiry:hover {
			background: #fbfbfb;
			color: #0099cc;
		}
		#woo_catalog_enquiry_custom_button {
			background: #fbfbfb;
			color: #fbfbfb;
			padding: 5px;
			width: 80px;
			height: 26px;
			line-height: 14px;
			border-radius: 5px;
			border: #fbfbfb;
			font-size: 12px;
			margin-top: 5px;
			margin-bottom: 5px;
			
		}
		#woo_catalog_enquiry_custom_button:hover {
			background: #fbfbfb;
			color: #fbfbfb;
		}
		/* The Modal (background) */
		#woo_catalog .catalog_modal {
			display: none; /* Hidden by default */
			position: fixed; /* Stay in place */
			z-index: 100000; /* Sit on top */
			/*padding-top: 100px;*/ /* Location of the box */
			left: 0;
			top: 0;
			width: 100%; /* Full width */
			height: 100%; /* Full height */
			overflow: auto; /* Enable scroll if needed */
			background-color: rgb(0,0,0); /* Fallback color */
			background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		}
	</style>

	<link rel='stylesheet' id='googlefont-cf7style-396-css'  href='https://fonts.googleapis.com/css?family=Rubik%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900&amp;subset=latin%2Clatin-ext%2Ccyrillic%2Ccyrillic-ext%2Cgreek-ext%2Cgreek%2Cvietnamese&amp;ver=5.5.1' type='text/css' media='all' />
	<script type='text/javascript' src='{{ asset('frontend/wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp') }}' id='jquery-core-js'></script>
	<link rel="https://api.w.org/" href="frontend/wp-json/index.html" /><link rel="alternate" type="application/json" href="wp-json/wp/v2/pages/42.json" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.html?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="frontend/wp-includes/wlwmanifest.xml" /> 
	<link rel="canonical" href="index.html" />
	<link rel='shortlink' href='index.html' />

	<style type="text/css"> 
		p.hello { font-size:12px; color:darkgray; }#google_language_translator, #flags { text-align:left; }#google_language_translator { clear:both; }#flags { width:165px; }#flags a { display:inline-block; margin-right:2px; }#google_language_translator a {display: none !important; }.goog-te-gadget {color:transparent !important;}.goog-te-gadget { font-size:0px !important; }.goog-branding { display:none; }.goog-tooltip {display: none !important;}.goog-tooltip:hover {display: none !important;}.goog-text-highlight {background-color: transparent !important; border: none !important; box-shadow: none !important;}#google_language_translator select.goog-te-combo { color:#32373c; }.goog-te-banner-frame{visibility:hidden !important;}body { top:0px !important;}#glt-translate-trigger { left:50%; margin-left:-63px; right:auto; }#glt-translate-trigger > span { color:#ffffff; }#glt-translate-trigger { background:#f89406; }.goog-te-gadget .goog-te-combo { width:100%; }
	</style>
	<script type="text/javascript">
		(function(url){
			if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
			var addEvent = function(evt, handler) {
				if (window.addEventListener) {
					document.addEventListener(evt, handler, false);
				} else if (window.attachEvent) {
					document.attachEvent('on' + evt, handler);
				}
			};
			var removeEvent = function(evt, handler) {
				if (window.removeEventListener) {
					document.removeEventListener(evt, handler, false);
				} else if (window.detachEvent) {
					document.detachEvent('on' + evt, handler);
				}
			};
			var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
			var logHuman = function() {
				if (window.wfLogHumanRan) { return; }
				window.wfLogHumanRan = true;
				var wfscr = document.createElement('script');
				wfscr.type = 'text/javascript';
				wfscr.async = true;
				wfscr.src = url + '&r=' + Math.random();
				(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
				for (var i = 0; i < evts.length; i++) {
					removeEvent(evts[i], logHuman);
				}
			};
			for (var i = 0; i < evts.length; i++) {
				addEvent(evts[i], logHuman);
			}
		})('index6d84.html?wordfence_lh=1&amp;hid=580D12B6A87D270D8C1444EB4CB71C3A');
	</script>			
	<style>
		.sydney-svg-icon {
			display: inline-block;
			width: 16px;
			height: 16px;
			vertical-align: middle;
			line-height: 1;
		}
		.team-item .team-social li .sydney-svg-icon {
			fill: #fff;
		}
		.team-item .team-social li:hover .sydney-svg-icon {
			fill: #000;
		}
		.team_hover_edits .team-social li a .sydney-svg-icon {
			fill: #000;
		}
		.team_hover_edits .team-social li:hover a .sydney-svg-icon {
			fill: #fff;
		}				
	</style>
	<noscript>
		<style>.woocommerce-product-gallery{ opacity: 1 !important; }
		</style>
	</noscript>
		
	<style class='cf7-style' media='screen' type='text/css'>
		body .cf7-style.transparent-two-columns,body .cf7-style.transparent-two-columns input[type='submit'] {font-family: 'Rubik',sans-serif;} 
	</style>
	<style type="text/css" media="all" id="siteorigin-panels-layouts-head">/* Layout 42 */
		#pgc-42-0-0 , #pgc-42-0-1 { width:50%;width:calc(50% - ( 0.5 * 30px ) ) } #pg-42-0 , #pg-42-1 , #pg-42-2 , #pl-42 .so-panel , #pl-42 .so-panel:last-child { margin-bottom:0px } #pgc-42-1-0 , #pgc-42-3-0 { width:100%;width:calc(100% - ( 0 * 30px ) ) } #pgc-42-2-0 , #pgc-42-2-1 , #pgc-42-2-2 { width:33.3333%;width:calc(33.3333% - ( 0.666666666667 * 30px ) ) } #pg-42-0.panel-no-style, #pg-42-0.panel-has-style > .panel-row-style , #pg-42-3.panel-no-style, #pg-42-3.panel-has-style > .panel-row-style { -webkit-align-items:center;align-items:center } #pg-42-1> .panel-row-style { padding:50px } #pg-42-1.panel-no-style, #pg-42-1.panel-has-style > .panel-row-style , #pg-42-2.panel-no-style, #pg-42-2.panel-has-style > .panel-row-style { -webkit-align-items:stretch;align-items:stretch } #panel-42-1-0-0> .panel-widget-style { color:#336618 } #pg-42-2> .panel-row-style { padding:75px } #pg-42-3> .panel-row-style { padding:25px } @media (max-width:780px){ #pg-42-0.panel-no-style, #pg-42-0.panel-has-style > .panel-row-style , #pg-42-1.panel-no-style, #pg-42-1.panel-has-style > .panel-row-style , #pg-42-2.panel-no-style, #pg-42-2.panel-has-style > .panel-row-style , #pg-42-3.panel-no-style, #pg-42-3.panel-has-style > .panel-row-style { -webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column } #pg-42-0 > .panel-grid-cell , #pg-42-0 > .panel-row-style > .panel-grid-cell , #pg-42-1 > .panel-grid-cell , #pg-42-1 > .panel-row-style > .panel-grid-cell , #pg-42-2 > .panel-grid-cell , #pg-42-2 > .panel-row-style > .panel-grid-cell , #pg-42-3 > .panel-grid-cell , #pg-42-3 > .panel-row-style > .panel-grid-cell { width:100%;margin-right:0 } #pgc-42-0-0 , #pgc-42-2-0 , #pgc-42-2-1 , #pl-42 .panel-grid .panel-grid-cell-mobile-last { margin-bottom:0px } #pg-42-0 , #pg-42-1 , #pg-42-2 , #pg-42-3 { margin-bottom:px } #pl-42 .panel-grid-cell { padding:0 } #pl-42 .panel-grid .panel-grid-cell-empty { display:none }  } 
	</style>
	<link rel="icon" href="{{ asset('frontend/wp-content/uploads/jdk_transparent-100x100.png') }}" sizes="32x32" />
	<link rel="icon" href="{{ asset('frontend/wp-content/uploads/jdk_transparent.png') }}" sizes="192x192" />
	<link rel="apple-touch-icon" href="{{ asset('frontend/wp-content/uploads/jdk_transparent.png') }}" />
	<meta name="msapplication-TileImage" content="" />

	<style type="text/css" id="wp-custom-css">
		/* Address lines style */
	.contact-address .address-lines {
	margin-top: -25px;
	margin-left: 28px;
	}

	/* Reduce footer widgets gap */
	.footer-widgets .sidebar-column .widget{
	padding-top: 0;
	padding-bottom: 0;
	}		
	</style>





<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from www.jdkfashion.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Oct 2020 05:34:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="xmlrpc.html">
    <title>Lira textile</title>
    @yield('title')
    @include('frontend.partials.style')
    @yield('style')
</head>
<body class="home page-template page-template-page-templates page-template-page_front-page page-template-page-templatespage_front-page-php page page-id-42 theme-sydney siteorigin-panels siteorigin-panels-before-js siteorigin-panels-home woocommerce-no-js menu-inline">
	@include('frontend.partials.header')
	
    <div id="content" class="page-wrap">  

            @yield('content')
            
        </div><!-- #content -->
        
    @include('frontend.partials.footer')	
    
	</div><!-- #page -->
@include('frontend.partials.script')
@yield('script')
</body>
<!-- Mirrored from www.jdkfashion.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Oct 2020 05:34:50 GMT -->
</html>

@extends('frontend.layouts.app')
<!--start section -->
@section('title')
<title>App</title>    
@endsection
@section('content')
    

@endsection   
<!--end section--> 

@section('script')
   
@endsection